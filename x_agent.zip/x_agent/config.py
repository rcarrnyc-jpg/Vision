"""
Central config. All secrets come from environment variables — never hardcode keys.

Required env vars (put these in a .env file next to this project, or export them):

  X_API_KEY, X_API_SECRET               - X (Twitter) app credentials
  X_ACCESS_TOKEN, X_ACCESS_TOKEN_SECRET - X user access tokens (your account)
  X_BEARER_TOKEN                        - X app-only bearer token (for read-heavy calls)
  ANTHROPIC_API_KEY                     - for content generation via Claude

Get X credentials at https://developer.x.com (you need at least Basic tier
for posting + mentions; Free tier is read-limited and won't work well for this).
"""
import os
from dotenv import load_dotenv

load_dotenv()

X_API_KEY = os.getenv("X_API_KEY")
X_API_SECRET = os.getenv("X_API_SECRET")
X_ACCESS_TOKEN = os.getenv("X_ACCESS_TOKEN")
X_ACCESS_TOKEN_SECRET = os.getenv("X_ACCESS_TOKEN_SECRET")
X_BEARER_TOKEN = os.getenv("X_BEARER_TOKEN")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

# Safety switch: when True, the agent NEVER posts/replies automatically.
# It writes drafts to review_queue.jsonl for you to approve via main.py review.
# Start with this True. Only flip to False once you trust the pipeline.
REQUIRE_HUMAN_APPROVAL = os.getenv("REQUIRE_HUMAN_APPROVAL", "true").lower() == "true"

# Your brand voice / posting rules — fed into every content-generation prompt.
BRAND_VOICE = os.getenv(
    "BRAND_VOICE",
    "Concise, direct, a little dry. No hashtags. No emoji spam. No engagement-bait phrasing.",
)

STATE_DIR = os.getenv("STATE_DIR", "./state")
os.makedirs(STATE_DIR, exist_ok=True)

def check_config(require_posting_creds: bool = True) -> list[str]:
    """Returns a list of missing required env vars."""
    missing = []
    if require_posting_creds:
        for name in ["X_API_KEY", "X_API_SECRET", "X_ACCESS_TOKEN", "X_ACCESS_TOKEN_SECRET"]:
            if not globals()[name]:
                missing.append(name)
    if not ANTHROPIC_API_KEY:
        missing.append("ANTHROPIC_API_KEY")
    return missing
