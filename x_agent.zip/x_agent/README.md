# X (Twitter) Agent

A custom agent that drafts and posts content, replies to mentions, and reports
on engagement for your X account — using the X API v2 and Claude for generation.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# fill in .env with your keys (see below)
```

### Getting X API credentials
1. Apply for a developer account at https://developer.x.com
2. Create a Project + App
3. You need at least the **Basic** paid tier — the Free tier can't post/read
   mentions in a way that's usable for this. Elevated/legacy tiers are deprecated.
4. Generate: API Key/Secret, Access Token/Secret (with **read + write** permissions),
   and a Bearer Token.

### Getting an Anthropic API key
Create one at https://console.anthropic.com

## Usage

```bash
# Draft a post (queued for your approval by default)
python main.py post "why most SaaS onboarding emails fail"

# Get content ideas without needing X credentials
python main.py ideas "B2B marketing"

# Check mentions and draft replies
python main.py mentions

# Engagement report
python main.py analytics

# See what's waiting for your sign-off
python main.py review

# Approve a specific draft (this is what actually posts it)
python main.py approve <id>
python main.py reject <id>

# Run continuously (checks mentions every 15 min)
python scheduler.py
```

## Safety design — read this

`REQUIRE_HUMAN_APPROVAL=true` (the default) means the agent **never posts on
its own**. It drafts, and you approve each one with `python main.py approve <id>`.
This exists for good reasons, not just caution for its own sake:

- **X's automation rules**: fully automated replies/DMs at any real volume can
  trip X's platform-manipulation and spam enforcement, especially automated
  engagement with other users' content. Read https://help.x.com/en/rules-and-policies/x-automation
  before turning approval off.
- **Brand risk**: an LLM drafting replies to strangers on the internet, unsupervised,
  will eventually say something wrong, tone-deaf, or embarrassing — with your name on it.
- **No real "CEO" mode**: I built this as draft-and-approve rather than fully
  autonomous. If you want it more hands-off later, the safer middle ground is
  auto-posting *scheduled original content* (things only you control the topic of)
  while keeping replies to strangers on manual approval indefinitely.

If you still want `REQUIRE_HUMAN_APPROVAL=false` for posting (not replies),
that's a reasonable call once you've reviewed enough drafts to trust the voice.
I'd keep replies on approval permanently, or at minimum add a keyword/sentiment
filter before auto-replying.

## Files

- `main.py` — CLI entrypoint
- `config.py` — env var loading, brand voice, safety switch
- `x_client.py` — X API v2 wrapper (tweepy)
- `content_generator.py` — Claude-powered drafting (posts, replies, ideas, analysis)
- `reply_handler.py` — fetches mentions, drafts replies
- `analytics.py` — engagement report
- `review_queue.py` — JSONL queue backing the approval workflow
- `scheduler.py` — runs mention-checking on a loop
