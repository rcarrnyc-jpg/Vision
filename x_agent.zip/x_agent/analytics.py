"""
Pulls your recent tweet performance and asks Claude to summarize patterns.
"""
from x_client import XClient
import content_generator


def run_report() -> str:
    client = XClient()
    tweets = client.get_recent_own_tweets(max_results=20)

    if not tweets:
        return "No recent tweets found."

    lines = []
    for t in tweets:
        m = t.public_metrics or {}
        lines.append(
            f"- \"{t.text[:80]}\" | likes={m.get('like_count', 0)} "
            f"retweets={m.get('retweet_count', 0)} replies={m.get('reply_count', 0)} "
            f"impressions={m.get('impression_count', 'n/a')}"
        )

    summary_input = "Recent tweet performance:\n" + "\n".join(lines)
    return content_generator.summarize_engagement(summary_input)


if __name__ == "__main__":
    print(run_report())
