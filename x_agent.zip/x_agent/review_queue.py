"""
Simple JSONL-backed queue for drafts pending human approval.
This is what makes REQUIRE_HUMAN_APPROVAL safe: nothing posts until you approve it.
"""
import json
import os
import time
import uuid
import config

QUEUE_PATH = os.path.join(config.STATE_DIR, "review_queue.jsonl")


def _load_all() -> list[dict]:
    if not os.path.exists(QUEUE_PATH):
        return []
    with open(QUEUE_PATH) as f:
        return [json.loads(line) for line in f if line.strip()]


def _save_all(items: list[dict]) -> None:
    with open(QUEUE_PATH, "w") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")


def add(kind: str, text: str, reply_to_id: str | None = None, context: str = "") -> dict:
    item = {
        "id": str(uuid.uuid4())[:8],
        "kind": kind,  # "post" | "reply"
        "text": text,
        "reply_to_id": reply_to_id,
        "context": context,
        "status": "pending",  # pending | approved | rejected | posted
        "created_at": time.time(),
    }
    items = _load_all()
    items.append(item)
    _save_all(items)
    return item


def pending() -> list[dict]:
    return [i for i in _load_all() if i["status"] == "pending"]


def set_status(item_id: str, status: str) -> None:
    items = _load_all()
    for i in items:
        if i["id"] == item_id:
            i["status"] = status
    _save_all(items)
