"""
Uses the Anthropic API to draft posts, replies, and content ideas in your brand voice.
"""
import anthropic
import config

_client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
MODEL = "claude-sonnet-4-6"


def _ask(system: str, user: str, max_tokens: int = 400) -> str:
    resp = _client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return "".join(block.text for block in resp.content if block.type == "text").strip()


def draft_post(topic: str) -> str:
    system = (
        f"You write X (Twitter) posts. Voice: {config.BRAND_VOICE} "
        "Hard limit 280 characters. Output ONLY the post text, nothing else."
    )
    return _ask(system, f"Write a post about: {topic}")


def draft_reply(original_text: str, author_handle: str) -> str:
    system = (
        f"You write X (Twitter) replies. Voice: {config.BRAND_VOICE} "
        "Hard limit 280 characters. Be genuinely responsive to what they said, "
        "don't just praise or agree reflexively. Output ONLY the reply text."
    )
    return _ask(system, f"@{author_handle} posted: \"{original_text}\"\n\nWrite a reply.")


def content_ideas(theme: str, n: int = 5) -> list[str]:
    system = (
        f"You brainstorm X (Twitter) content ideas. Voice: {config.BRAND_VOICE} "
        f"Output exactly {n} ideas, one per line, no numbering, no extra commentary."
    )
    raw = _ask(system, f"Theme: {theme}", max_tokens=500)
    return [line.strip("-• ").strip() for line in raw.splitlines() if line.strip()]


def summarize_engagement(tweets_summary: str) -> str:
    system = (
        "You are a social media analyst. Given tweet performance data, identify "
        "2-3 concrete patterns (what's working, what isn't) and one actionable "
        "recommendation. Be specific and brief — no generic advice."
    )
    return _ask(system, tweets_summary, max_tokens=500)
