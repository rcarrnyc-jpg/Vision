"""
Runs the agent's recurring jobs: check mentions periodically, and
optionally post scheduled content. Run with: python scheduler.py
"""
from apscheduler.schedulers.blocking import BlockingScheduler
import reply_handler
import config


def job_check_mentions():
    results = reply_handler.process_mentions()
    if results:
        print(f"[mentions] {len(results)} new mention(s) processed "
              f"({'queued for review' if config.REQUIRE_HUMAN_APPROVAL else 'posted'})")


def start():
    missing = config.check_config()
    if missing:
        print(f"Missing required env vars: {missing}. Set them in .env before running.")
        return

    sched = BlockingScheduler()
    sched.add_job(job_check_mentions, "interval", minutes=15, id="check_mentions")
    print("Scheduler running. Checking mentions every 15 minutes. Ctrl+C to stop.")
    print(f"Human approval required before posting: {config.REQUIRE_HUMAN_APPROVAL}")
    try:
        sched.start()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    start()
