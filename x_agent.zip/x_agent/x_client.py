"""
Thin wrapper around tweepy's X API v2 client.
Keeps all raw API calls in one place so the rest of the agent doesn't touch tweepy directly.
"""
import tweepy
import config


def get_client() -> tweepy.Client:
    return tweepy.Client(
        bearer_token=config.X_BEARER_TOKEN,
        consumer_key=config.X_API_KEY,
        consumer_secret=config.X_API_SECRET,
        access_token=config.X_ACCESS_TOKEN,
        access_token_secret=config.X_ACCESS_TOKEN_SECRET,
        wait_on_rate_limit=True,
    )


class XClient:
    def __init__(self):
        self.client = get_client()
        self._me = None

    def me(self):
        if self._me is None:
            self._me = self.client.get_me().data
        return self._me

    def post_tweet(self, text: str, reply_to_id: str | None = None) -> dict:
        resp = self.client.create_tweet(
            text=text,
            in_reply_to_tweet_id=reply_to_id,
        )
        return resp.data

    def delete_tweet(self, tweet_id: str) -> bool:
        resp = self.client.delete_tweet(tweet_id)
        return resp.data.get("deleted", False)

    def get_mentions(self, since_id: str | None = None, max_results: int = 20):
        me = self.me()
        resp = self.client.get_users_mentions(
            id=me.id,
            since_id=since_id,
            max_results=max_results,
            tweet_fields=["created_at", "author_id", "conversation_id", "public_metrics"],
            expansions=["author_id"],
        )
        return resp.data or [], (resp.includes.get("users", []) if resp.includes else [])

    def get_recent_own_tweets(self, max_results: int = 20):
        me = self.me()
        resp = self.client.get_users_tweets(
            id=me.id,
            max_results=max_results,
            tweet_fields=["created_at", "public_metrics"],
        )
        return resp.data or []
