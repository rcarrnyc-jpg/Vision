"""
Fetches new mentions and drafts replies (queued for approval unless
REQUIRE_HUMAN_APPROVAL is False).
"""
import json
import os
import config
from x_client import XClient
import content_generator
import review_queue

LAST_SEEN_PATH = os.path.join(config.STATE_DIR, "last_mention_id.txt")


def _get_since_id() -> str | None:
    if os.path.exists(LAST_SEEN_PATH):
        return open(LAST_SEEN_PATH).read().strip() or None
    return None


def _set_since_id(tweet_id: str) -> None:
    with open(LAST_SEEN_PATH, "w") as f:
        f.write(str(tweet_id))


def process_mentions() -> list[dict]:
    """Fetch new mentions, draft replies, queue or post them. Returns queued/posted items."""
    client = XClient()
    since_id = _get_since_id()
    mentions, users = client.get_mentions(since_id=since_id)
    user_by_id = {u.id: u for u in users}

    results = []
    max_id_seen = since_id
    for tweet in mentions:
        author = user_by_id.get(tweet.author_id)
        handle = author.username if author else "user"
        draft = content_generator.draft_reply(tweet.text, handle)

        if config.REQUIRE_HUMAN_APPROVAL:
            item = review_queue.add(
                kind="reply", text=draft, reply_to_id=tweet.id,
                context=f"Replying to @{handle}: {tweet.text}",
            )
            results.append(item)
        else:
            posted = client.post_tweet(draft, reply_to_id=tweet.id)
            results.append({"kind": "reply", "posted": True, "data": posted})

        if max_id_seen is None or int(tweet.id) > int(max_id_seen):
            max_id_seen = tweet.id

    if max_id_seen:
        _set_since_id(max_id_seen)

    return results


if __name__ == "__main__":
    results = process_mentions()
    print(json.dumps(results, indent=2, default=str))
