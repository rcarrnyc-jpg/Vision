"""
CLI for the X agent.

Usage:
  python main.py post "topic"          Draft a post about a topic (queues or posts)
  python main.py ideas "theme"         Generate content ideas
  python main.py mentions              Check + draft replies to new mentions
  python main.py analytics             Run an engagement report
  python main.py review                List drafts pending approval
  python main.py approve <id>          Approve and publish a queued draft
  python main.py reject <id>           Reject a queued draft
"""
import sys
import config
import content_generator
import review_queue
from x_client import XClient


def cmd_post(topic: str):
    draft = content_generator.draft_post(topic)
    if config.REQUIRE_HUMAN_APPROVAL:
        item = review_queue.add(kind="post", text=draft, context=f"Topic: {topic}")
        print(f"Queued for review [{item['id']}]:\n{draft}")
    else:
        client = XClient()
        posted = client.post_tweet(draft)
        print(f"Posted: {draft}\n-> {posted}")


def cmd_ideas(theme: str):
    for idea in content_generator.content_ideas(theme):
        print(f"- {idea}")


def cmd_mentions():
    import reply_handler
    results = reply_handler.process_mentions()
    print(f"{len(results)} mention(s) processed.")
    for r in results:
        print(r)


def cmd_analytics():
    import analytics
    print(analytics.run_report())


def cmd_review():
    items = review_queue.pending()
    if not items:
        print("Nothing pending.")
        return
    for i in items:
        print(f"[{i['id']}] ({i['kind']}) {i['text']}")
        if i.get("context"):
            print(f"    context: {i['context']}")


def cmd_approve(item_id: str):
    items = review_queue.pending()
    match = next((i for i in items if i["id"] == item_id), None)
    if not match:
        print("No pending item with that id.")
        return
    client = XClient()
    posted = client.post_tweet(match["text"], reply_to_id=match.get("reply_to_id"))
    review_queue.set_status(item_id, "posted")
    print(f"Posted: {match['text']}\n-> {posted}")


def cmd_reject(item_id: str):
    review_queue.set_status(item_id, "rejected")
    print(f"Rejected [{item_id}].")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return

    missing = config.check_config(require_posting_creds=sys.argv[1] not in ("ideas",))
    if missing:
        print(f"Missing required env vars: {missing}. Copy .env.example to .env and fill it in.")
        return

    cmd, *args = sys.argv[1:]
    commands = {
        "post": cmd_post,
        "ideas": cmd_ideas,
        "mentions": lambda: cmd_mentions(),
        "analytics": lambda: cmd_analytics(),
        "review": lambda: cmd_review(),
        "approve": cmd_approve,
        "reject": cmd_reject,
    }
    if cmd not in commands:
        print(__doc__)
        return
    commands[cmd](*args) if args else commands[cmd]()


if __name__ == "__main__":
    main()
